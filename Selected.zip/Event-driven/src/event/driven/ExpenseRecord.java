/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package event.driven;

/**
 *
 * @author ph
 */
public class ExpenseRecord {
    private String date;
    private String description;
    private double amount;
    private String type;

    public ExpenseRecord(String date, String description, double amount, String type) {
        this.date = date;
        this.description = description;
        this.amount = amount;
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "Date: " + date + " | Description: " + description + " | Amount: " + amount + " | Type: " + type;
    }
}

