/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package event.driven;

/**
 *
 * @author ph
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ExpenseTrackerApp {
    private JFrame frame;
    private JTextField dateField, descriptionField, amountField;
    private JComboBox<String> typeComboBox;
    private DefaultListModel<ExpenseRecord> recordsListModel;
    private JList<ExpenseRecord> recordsList;
    private List<ExpenseRecord> records = new ArrayList<>();
    private double totalIncome = 0.0;
    private double totalExpense = 0.0;
    private JLabel balanceLabel;

    public ExpenseTrackerApp() {
        frame = new JFrame("Expense Income Tracker");

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2));

        inputPanel.add(new JLabel("Date:"));
        dateField = new JTextField();
        inputPanel.add(dateField);

        inputPanel.add(new JLabel("Description:"));
        descriptionField = new JTextField();
        inputPanel.add(descriptionField);

        inputPanel.add(new JLabel("Amount:"));
        amountField = new JTextField();
        inputPanel.add(amountField);

        inputPanel.add(new JLabel("Type:"));
        String[] types = {"Expense", "Income"};
        typeComboBox = new JComboBox<>(types);
        inputPanel.add(typeComboBox);
        
        balanceLabel = new JLabel("Balance: $0.00");
        inputPanel.add(balanceLabel);

        JButton addRecordButton = new JButton("Add Record");
        addRecordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRecord();
            }
        });

        inputPanel.add(addRecordButton);

        recordsListModel = new DefaultListModel<>();
        recordsList = new JList<>(recordsListModel);

        frame.setLayout(new BorderLayout());
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(recordsList), BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        frame.setVisible(true);
    }

    private void addRecord() {
        String date = dateField.getText();
        String description = descriptionField.getText();
        String amountStr = amountField.getText();
        String type = (String) typeComboBox.getSelectedItem();

        try {
            double amount = Double.parseDouble(amountStr);

            if ("Expense".equals(type)) {
                totalExpense += amount;
            } else if ("Income".equals(type)) {
                totalIncome += amount;
            }

            ExpenseRecord record = new ExpenseRecord(date, description, amount, type);
            records.add(record);
            recordsListModel.addElement(record);

            // 更新余额
            double balance = totalIncome - totalExpense;
            balanceLabel.setText("Balance: $" + String.format("%.2f", balance)); // 更新余额标签的文本

            // 清空输入字段
            dateField.setText("");
            descriptionField.setText("");
            amountField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid amount.");
        }
    }
}
