/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package layered;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author ph
 */
public class ExpenseIncomeTrackerUI {
    private TransactionService transactionService;
    private DefaultListModel<String> transactionListModel;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private JTextField dateTextField;
    private JTextField descriptionTextField;
    private JTextField amountTextField;
    private JLabel balanceLabel;
    private JTable transactionTable;

    public ExpenseIncomeTrackerUI(TransactionService transactionService) {
        this.transactionService = transactionService;
        transactionListModel = new DefaultListModel<>();
    }

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Expense Income Tracker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);


        UIManager.put("Panel.background", new Color (215, 229, 202));
        UIManager.put("OptionPane.background", new Color(249, 243, 204));
        UIManager.put("Button.background", new Color(249,243,204));
        UIManager.put("Menu.foreground", new Color(142,172,205));

        UIManager.put("Lable.foreground", new Color(249,148,23));
        

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Date: "), gbc);
        dateTextField = new JTextField(20);
        gbc.gridx = 1;
        inputPanel.add(dateTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Description: "), gbc);
        descriptionTextField = new JTextField(20);
        gbc.gridx = 1;
        inputPanel.add(descriptionTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("Amount: "), gbc);
        amountTextField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(amountTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        inputPanel.add(new JLabel("Type: "), gbc);
        JComboBox<String> transactionTypeComboBox = new JComboBox<>(new String[]{"Expense", "Income"});
        gbc.gridx = 1;
        inputPanel.add(transactionTypeComboBox, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        JButton addButton = new JButton("Add Transaction");
        inputPanel.add(addButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        balanceLabel = new JLabel("Balance: $0.00");
        inputPanel.add(balanceLabel, gbc);

        mainPanel.add(inputPanel, BorderLayout.NORTH);

        transactionTable = new JTable(new DefaultTableModel(new Object[]{"Date", "Description", "Amount", "Type"}, 0));
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        // Adding a drop-down box control
        JComboBox<String> sortComboBox = new JComboBox<>(new String[]{"Date", "Amount"});
        JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"Category", "No Category"});

        // Add a button to trigger the update of the transaction list.
        JButton updateButton = new JButton("Update");
        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Date date = dateFormat.parse(dateTextField.getText());
                    String description = descriptionTextField.getText();
                    double amount = Double.parseDouble(amountTextField.getText());
                    TransactionType type = transactionTypeComboBox.getSelectedItem().equals("Expense") ? TransactionType.EXPENSE : TransactionType.INCOME;

                    // Add the transaction to the data layer
                    transactionService.addTransaction(date, description, amount, type);

                    // Update transaction list and balance
                    updateTransactionTable();
                    updateBalance();
      
                    dateTextField.setText("");
                    descriptionTextField.setText("");
                    amountTextField.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid date format. Please use 'yyyy-MM-dd'.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private void updateTransactionTable() {
        DefaultTableModel tableModel = (DefaultTableModel) transactionTable.getModel();
        tableModel.setRowCount(0);

        List<Transaction> transactions = transactionService.getAllTransactions();
        for (Transaction transaction : transactions) {
            String type = (transaction.getType() == TransactionType.EXPENSE) ? "Expense" : "Income";
            tableModel.addRow(new Object[]{dateFormat.format(transaction.getDate()), transaction.getDescription(), transaction.getAmount(), type});
        }
    }

    private void updateBalance() {
        List<Transaction> transactions = transactionService.getAllTransactions();
        double balance = 0.0;
        for (Transaction transaction : transactions) {
            if (transaction.getType() == TransactionType.EXPENSE) {
                balance -= transaction.getAmount();
            } else {
                balance += transaction.getAmount();
            }
        }
        balanceLabel.setText("Balance: $" + String.format("%.2f", balance));
    }
    
}
