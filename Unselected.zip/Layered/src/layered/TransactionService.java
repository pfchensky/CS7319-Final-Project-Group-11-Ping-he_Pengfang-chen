/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package layered;

import java.util.Date;
import java.util.List;

/**
 *
 * @author ph
 */
public class TransactionService {
    private TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

 

    public List<Transaction> getAllTransactions() {
        return transactionRepository.getAllTransactions();
    }
    
    public void addTransaction(Date date, String description, double amount, TransactionType type) {
    Transaction transaction = new Transaction(date, description, amount, type);
    transactionRepository.addTransaction(transaction);
}

    
}
