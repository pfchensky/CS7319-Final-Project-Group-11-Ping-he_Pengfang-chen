/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package layered;

import javax.swing.SwingUtilities;

/**
 *
 * @author ph
 */
public class Layered {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TransactionRepository transactionRepository = new TransactionRepository();
                TransactionService transactionService = new TransactionService(transactionRepository);
                ExpenseIncomeTrackerUI appUI = new ExpenseIncomeTrackerUI(transactionService);
                appUI.createAndShowGUI();
            }
        });
    }
    
}
