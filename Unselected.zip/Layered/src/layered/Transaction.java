/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package layered;

import java.util.Date;

/**
 *
 * @author ph
 */
public class Transaction {
    private Date date;
    private String description;
    private double amount;
    private TransactionType type;

    public Transaction(Date date, String description, double amount, TransactionType type) {
        this.date = date;
        this.description = description;
        this.amount = amount;
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public double getAmount() {
        return amount;
    }

    public TransactionType getType() {
        return type;
    }
}

enum TransactionType {
    EXPENSE, INCOME
}
